<?php
/*
Template Name: Blog
*/
?>


<?php include ('archive.php') ?>